package com.sleepmate.pro;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_NOTIF = 1001;
    private static volatile boolean appVisible = false;

    private WebView webView;
    private boolean pageLoaded = false;
    private boolean pendingNotificationTap = false;
    private boolean permissionDialogOpen = false;

    public static boolean isAppVisible() {
        return appVisible;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(0xFF060914);
        getWindow().setNavigationBarColor(0xFF060914);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF060914);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        if (Build.VERSION.SDK_INT >= 26) {
            s.setSafeBrowsingEnabled(false);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("file://") || url.startsWith("about:")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                consumePendingTap();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                try {
                    request.grant(request.getResources());
                } catch (Exception ignored) {
                }
            }
        });

        webView.addJavascriptInterface(new NativeBridge(), "AndroidNative");

        pendingNotificationTap = getIntent() != null
                && getIntent().getBooleanExtra("from_notification", false);

        NotificationHelper.createChannels(this);
        webView.loadUrl("file:///android_asset/www/index.html");
        askNotificationPermission();
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionDialogOpen = true;
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            permissionDialogOpen = false;
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (!granted) {
                Toast.makeText(this,
                        "Bạn có thể bật lại trong Cài đặt > Ứng dụng > SLEEPMATE > Thông báo.",
                        Toast.LENGTH_LONG).show();
            }
            evalJs("window.updateNotificationStatusUI && window.updateNotificationStatusUI();");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("from_notification", false)) {
            pendingNotificationTap = true;
            consumePendingTap();
        }
    }

    private void consumePendingTap() {
        if (pendingNotificationTap && pageLoaded) {
            pendingNotificationTap = false;
            evalJs("window.onNativeNotificationTap && window.onNativeNotificationTap();");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        appVisible = true;
        NotificationScheduler.cancelGuard(this);
        if (webView != null) webView.onResume();
        consumePendingTap();
        evalJs("window.updateNotificationStatusUI && window.updateNotificationStatusUI();");
    }

    @Override
    protected void onPause() {
        appVisible = false;
        if (webView != null) webView.onPause();
        if (!isFinishing() && !permissionDialogOpen && NotificationScheduler.isGuardConfigured(this)) {
            NotificationScheduler.scheduleGuard(this, NotificationScheduler.getRepeatSec(this));
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try {
                webView.removeJavascriptInterface("AndroidNative");
                webView.destroy();
            } catch (Exception ignored) {
            }
            webView = null;
        }
        super.onDestroy();
    }

    private void evalJs(final String code) {
        if (webView == null) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    webView.evaluateJavascript(code, null);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private class NativeBridge {

        @JavascriptInterface
        public boolean isNativeApp() {
            return true;
        }

        @JavascriptInterface
        public boolean hasNotificationPermission() {
            if (Build.VERSION.SDK_INT >= 33) {
                return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;
            }
            return NotificationHelper.areNotificationsEnabled(MainActivity.this);
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    askNotificationPermission();
                }
            });
        }

        @JavascriptInterface
        public void notifyNow(String title, String body) {
            NotificationHelper.show(MainActivity.this,
                    title == null ? "SLEEPMATE" : title,
                    body == null ? "" : body,
                    NotificationHelper.ID_GUARD, false);
        }

        @JavascriptInterface
        public void setGuardConfig(boolean enabled, int repeatSec) {
            NotificationScheduler.setGuardConfig(MainActivity.this, enabled, repeatSec);
        }

        @JavascriptInterface
        public void scheduleGuard(int repeatSec) {
            NotificationScheduler.scheduleGuard(MainActivity.this, repeatSec);
        }

        @JavascriptInterface
        public void cancelGuard() {
            NotificationScheduler.cancelGuard(MainActivity.this);
        }

        @JavascriptInterface
        public void scheduleDaily(int hour, int minute) {
            NotificationScheduler.scheduleDaily(MainActivity.this, hour, minute);
        }

        @JavascriptInterface
        public void cancelDaily() {
            NotificationScheduler.cancelDaily(MainActivity.this);
        }

        @JavascriptInterface
        public void setKeepScreenOn(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (on) {
                        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                }
            });
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            NotificationHelper.vibrate(MainActivity.this, ms);
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent();
                        if (Build.VERSION.SDK_INT >= 26) {
                            i.setAction(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                            i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, getPackageName());
                        } else {
                            i.setAction(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            i.setData(Uri.parse("package:" + getPackageName()));
                        }
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public String getVersionName() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "3.0";
            }
        }
    }
}
