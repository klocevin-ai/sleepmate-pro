# SLEEPMATE Pro — Toàn bộ mã nguồn

Gói này chứa **tất cả** mã nguồn của SLEEPMATE Pro: bản web (PWA), bản Android (APK) và ứng dụng một file.

## Cấu trúc

```
SLEEPMATE-full-source/
├── sleepmate-pro.html          ← BẢN GỐC: toàn bộ app trong 1 file (4.218 dòng)
│
├── pwa/                        ← Bản PWA để deploy lên Netlify/Cloudflare
│   ├── index.html              ← = sleepmate-pro.html (bản sao, giữ nguyên)
│   ├── sw.js                   ← Service Worker (cache offline, click thông báo, push)
│   ├── manifest.webmanifest    ← Tên app, icon, màu, standalone
│   ├── icon-192.png
│   ├── icon-512.png
│   ├── icon-maskable-512.png
│   ├── apple-touch-icon.png
│   └── README.md               ← Hướng dẫn cài cho iPhone + Android
│
└── android/                    ← Dự án Gradle để build APK
    ├── settings.gradle
    ├── build.gradle
    ├── gradle.properties
    └── app/
        ├── build.gradle
        ├── proguard-rules.pro
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/sleepmate/pro/
            │   ├── MainActivity.java           ← WebView + cầu nối AndroidNative
            │   ├── NotificationHelper.java     ← Tạo kênh, hiện thông báo, rung
            │   ├── NotificationScheduler.java  ← AlarmManager: chuỗi nhắc + giới nghiêm
            │   ├── GuardReceiver.java          ← Nhận báo thức, đăng thông báo
            │   └── BootReceiver.java           ← Đặt lại báo thức sau khi reboot
            ├── res/
            │   ├── drawable/ic_stat_sleep.xml  ← Icon thông báo (vector)
            │   ├── mipmap-*/ic_launcher.png    ← Icon app 5 mật độ
            │   ├── mipmap-*/ic_launcher_round.png
            │   └── values/{strings,styles}.xml
            └── assets/www/                     ← Toàn bộ app nhúng vào APK
                ├── index.html                  ← Bản HTML đã đổi CDN → vendor local
                ├── vendor/tailwind.js
                ├── vendor/fontawesome/...
                └── (icon + manifest)
```

## Điểm khác biệt duy nhất giữa 3 bản HTML

| File | Tailwind | Font Awesome |
|---|---|---|
| `sleepmate-pro.html` | `https://cdn.tailwindcss.com` | `cdnjs.cloudflare.com/...all.min.css` |
| `pwa/index.html` | giống hệt bản gốc | giống hệt bản gốc |
| `android/.../assets/www/index.html` | `./vendor/tailwind.js` | `./vendor/fontawesome/css/all.min.css` |

Ngoài 2 dòng đó, ba file **byte-for-byte giống nhau** (chỉ khác 44 byte do độ dài URL).

## Chạy thử PWA trên máy tính

```bash
# Cần HTTP server, KHÔNG mở file:// (service worker sẽ không chạy)
cd pwa
npx serve .
# hoặc: npx http-server . -p 8080
```

Mở `http://localhost:8080`. `localhost` được coi là secure context nên Service Worker + Notification hoạt động.

## Build lại APK

Yêu cầu: **JDK 17**, **Android SDK** (platform 34, build-tools 34), **Gradle 8.7**.

```bash
export JAVA_HOME=/path/to/jdk-17
export ANDROID_HOME=/path/to/android-sdk
cd android
gradle assembleDebug --no-daemon
# APK: app/build/outputs/apk/debug/app-debug.apk
```

> **Quan trọng:** Gradle không build được từ đường dẫn có dấu tiếng Việt (`Bad pathname`). Hãy copy thư mục `android/` sang đường dẫn ASCII thuần, ví dụ `C:\build\sleepmate`, rồi build từ đó.

## Cập nhật app sau này

1. Sửa `sleepmate-pro.html` (nguồn chân lý duy nhất).
2. Copy đè sang `pwa/index.html`.
3. Nếu đổi logic/cache: tăng `CORE_CACHE` + `RUNTIME_CACHE` trong `pwa/sw.js` (hiện là `v4`).
4. Với APK: copy đè `sleepmate-pro.html` vào `android/app/src/main/assets/www/index.html`, rồi đổi 2 dòng CDN thành vendor local (xem bảng trên).
5. Build lại APK.

## Kiến trúc tổng quan

**Frontend (HTML/JS)** — một file duy nhất, không framework:

- `usage` tracking: đếm `activeSec` / `idleSec` / `bgSec`, `opens`, `leaves`, biểu đồ 12 giờ, danh sách phiên
- `Notifier` — trừu tượng hoá thông báo: Web Notification + Service Worker (PWA) hoặc cầu nối native (APK)
- `NativeApp` — wrapper an toàn quanh `window.AndroidNative` (mọi method có try/catch, PWA trả về `null`)
- `IS_NATIVE_APP` — tính 1 lần lúc load; quyết định toàn bộ nhánh UI/notification
- Lưu trữ: `localStorage` key `sleepmate.pro.v3`, rollover theo "đêm" (mốc 04:00)

**Android (Java)**:

- `MainActivity` — WebView nạp `file:///android_asset/www/index.html`, gắn `addJavascriptInterface(new NativeBridge(), "AndroidNative")`
- `NotificationScheduler` — đặt 8 alarm tăng dần khi rời app; 1 alarm lặp ngày cho giới nghiêm; lưu cấu hình vào `SharedPreferences`
- `GuardReceiver` — nhận alarm → `NotificationHelper.show()`; tự đặt lại alarm giới nghiêm kế tiếp
- `BootReceiver` — `BOOT_COMPLETED` / `MY_PACKAGE_REPLACED` → `rescheduleAll()`
- `MainActivity.onPause()` → `scheduleGuard()`; `onResume()` → `cancelGuard()`

## Giới hạn đã biết

- Không đọc được thời gian dùng app khác (cần Usage Access trên Android; iOS không cho phép).
- iPhone: thông báo khi app đóng hẳn cần Web Push + máy chủ.
- APK ký bằng debug key — cài trực tiếp được, không đăng Play Store.
- Một số máy tối ưu pin mạnh (Xiaomi/OPPO/vivo/Samsung) có thể trễ báo thức nếu không tắt tối ưu pin.
