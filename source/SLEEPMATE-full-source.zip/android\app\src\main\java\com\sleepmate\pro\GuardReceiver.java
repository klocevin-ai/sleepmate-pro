package com.sleepmate.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class GuardReceiver extends BroadcastReceiver {

    public static final String ACTION_GUARD = "com.sleepmate.pro.GUARD";
    public static final String ACTION_CURFEW = "com.sleepmate.pro.CURFEW";

    private static final String[] TITLES = {
            "⏰ Quay lại SLEEPMATE",
            "⏰ Đừng lướt nữa",
            "⏰ Máy cần được nghỉ",
            "⏰ Cảnh báo cuối"
    };

    private static final String[] BODIES = {
            "Bạn vừa rời app. Quay lại và giải câu đố để tắt nhắc nhở.",
            "Đã vài phút ngoài màn hình. Mở SLEEPMATE ngay nhé.",
            "Mắt và não cần được nghỉ. Quay lại app và gập máy đi ngủ.",
            "Đêm nay bạn đã dùng khá nhiều thời gian. Hãy đi ngủ ngay."
    };

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (intent == null) return;
        NotificationHelper.createChannels(ctx);

        String action = intent.getAction();

        if (ACTION_CURFEW.equals(action)) {
            if (!MainActivity.isAppVisible()) {
                NotificationHelper.show(ctx,
                        "🌙 Đã tới giới nghiêm",
                        "Mở SLEEPMATE để khóa máy và đi ngủ. Hẹn gặp lại sáng mai!",
                        NotificationHelper.ID_CURFEW, false);
            }
            SharedPreferences p = NotificationScheduler.prefs(ctx);
            if (p.getBoolean(NotificationScheduler.KEY_CURFEW_ENABLED, false)) {
                NotificationScheduler.scheduleNextCurfew(ctx,
                        p.getInt(NotificationScheduler.KEY_CURFEW_HOUR, 23),
                        p.getInt(NotificationScheduler.KEY_CURFEW_MIN, 0));
            }
            return;
        }

        if (ACTION_GUARD.equals(action)) {
            if (MainActivity.isAppVisible()) return;
            int index = intent.getIntExtra("index", 0);
            int level = Math.min(3, Math.max(0, index / 2));
            NotificationHelper.show(ctx,
                    TITLES[level],
                    BODIES[level],
                    NotificationHelper.ID_GUARD, false);
        }
    }
}
