# SLEEPMATE Pro — Bộ cài cho iPhone & Android

Có **2 cách dùng**, chọn theo máy của bạn:

| | 🍎 iPhone / iPad | 🤖 Android |
|---|---|---|
| **Cách 1 — PWA (khuyên dùng cho iPhone)** | Safari → Chia sẻ → **Thêm vào MH chính** | Chrome → **Cài app** |
| **Cách 2 — APK (khuyên dùng cho Android)** | Không hỗ trợ (Apple không cho cài APK ngoài App Store) | Cài file `SLEEPMATE-Pro-Android.apk` |

> **Điểm khác biệt lớn nhất:** bản **APK Android** dùng báo thức hệ thống (`AlarmManager` + `NotificationManager`) nên vẫn nhắc nhở **kể cả khi bạn đã đóng hẳn app**. Bản PWA chỉ nhắc chắc chắn khi app còn mở hoặc vừa rời ra.

---

## Nội dung thư mục

| File | Vai trò |
|---|---|
| `index.html` | Toàn bộ ứng dụng PWA (bản giống `../sleepmate-pro.html`) |
| `manifest.webmanifest` | Tên app, icon, màu, chế độ standalone |
| `sw.js` | Service Worker: cache để mở khi mất mạng + xử lý bấm thông báo |
| `icon-192.png`, `icon-512.png` | Icon app |
| `icon-maskable-512.png` | Icon cho Android (bo tròn tự động) |
| `apple-touch-icon.png` | Icon 180×180 cho iPhone |
| `README.md` | File này |

Ngoài thư mục này, ở thư mục cha có:

| File | Vai trò |
|---|---|
| `SLEEPMATE-Pro-Android.apk` | Bản Android đầy đủ, cài trực tiếp |
| `sleepmate-pwa.zip` | Bản nén để kéo thả lên Netlify |
| `sleepmate-android/` | Mã nguồn APK (Gradle + WebView + Java) |

---

## Tính năng theo nền tảng

| | 🤖 Android APK | 🤖 Android PWA | 🍎 iPhone PWA |
|---|---|---|---|
| Cài app | Cài file APK | Chrome → Cài app | Safari → Thêm vào MH chính |
| Thông báo khi đang mở | ✅ | ✅ | ✅ (iOS 16.4+) |
| Thông báo khi vừa thoát | ✅ | ✅ | ✅ |
| **Thông báo khi đã đóng hẳn app** | ✅ **Báo thức hệ thống** | ⚠️ Hệ điều hành có thể tạm dừng | ❌ Cần Web Push + máy chủ |
| Rung | ✅ | ✅ | ❌ iOS không hỗ trợ |
| Âm thanh báo động | ✅ | ✅ | ✅ (sau lần chạm đầu) |
| Giữ màn hình sáng | ✅ | ✅ (Wake Lock) | ✅ (iOS 16.4+) |
| Nhắc giới nghiêm hằng ngày | ✅ Kể cả khi app đóng | ⚠️ Khi app còn chạy | ⚠️ Khi app còn chạy |
| Tự đặt lại báo thức sau reboot | ✅ | ❌ | ❌ |
| Hướng dẫn cài trong app | ✅ | ✅ | ✅ |

---

# CÁCH 1 — PWA cho cả iPhone và Android

## Bước 1 — Đưa lên HTTPS (miễn phí, 2 phút)

### Netlify Drop (nhanh nhất)

1. Mở **https://app.netlify.com/drop** trên máy tính.
2. Kéo **file `sleepmate-pwa.zip`** (hoặc cả thư mục `sleepmate-pwa`) thả vào ô của Netlify.
3. Đợi ~20 giây, Netlify cho bạn link dạng `https://ten-ngau-nhien.netlify.app`.
4. (Nên làm) Vào **Site settings → Change site name** để đổi thành `sleepmate-cua-ban.netlify.app`.

### Cách khác

- **Cloudflare Pages**: Create project → Direct Upload → kéo thư mục.
- **GitHub Pages**: đưa các file vào repo → Settings → Pages → chọn nhánh `main` / thư mục `/root`.

> ⚠️ Không dùng `file://` trên điện thoại: trình duyệt sẽ **không cho cấp quyền thông báo** và không cài được app. Bắt buộc phải là `https://`.

## Bước 2 — Cài app

Trong app có nút **Hướng dẫn cài** ở tab **Câu Đố & Thông Báo**. Nút này tự nhận diện máy và hiện đúng từng bước, kèm nút **Sao chép link** để gửi sang máy khác.

### Android (Chrome / Edge / Samsung Internet)

1. Mở link Netlify bằng Chrome.
2. Bấm nút **“Cài app”** trong tab **Câu Đố & Thông Báo**, hoặc menu **⋮ → “Cài đặt ứng dụng” / “Thêm vào màn hình chính”**.
3. Mở SLEEPMATE từ icon ngoài màn hình chính.

### iPhone (Safari)

1. Mở link bằng **Safari** (bắt buộc Safari — Chrome trên iOS không cài được PWA).
2. Bấm nút **Chia sẻ** (hình vuông có mũi tên) → **“Thêm vào MH chính”** → **Thêm**.
3. Mở app từ icon vừa tạo.

## Bước 3 — Bật thông báo

1. Trong app: tab **Câu Đố & Thông Báo** → **Bật thông báo** → chọn **Cho phép**.
2. Bấm **Test** để thử.
3. Bật **“Báo động khi thoát màn hình”** và chọn tần suất 15/30/60 giây.

**Android:** vào Cài đặt điện thoại → Ứng dụng → SLEEPMATE → Thông báo → bật **“Hiển thị trên màn hình khóa”**, cho phép **âm thanh/rung**.

**iPhone:** nếu bấm **Bật thông báo** mà app mở bảng hướng dẫn, nghĩa là bạn chưa cài app hoặc iOS < 16.4. Hãy Thêm vào MH chính rồi mở lại từ icon.

---

# CÁCH 2 — APK Android (thông báo cả khi đóng app)

## Bước 1 — Chép APK sang điện thoại

Chép file **`SLEEPMATE-Pro-Android.apk`** sang điện thoại bằng:
- Cáp USB, Google Drive, Zalo/Telegram (gửi cho chính mình), hoặc
- Mở link tải trực tiếp nếu bạn đã upload file lên hosting.

## Bước 2 — Cài APK

1. Mở file APK trên điện thoại.
2. Nếu Android hỏi **“Cài đặt ứng dụng không rõ nguồn gốc”**, bấm **Cài đặt** → bật **Cho phép từ nguồn này** cho ứng dụng bạn đang dùng (Files, Chrome, Zalo…).
3. Quay lại và bấm **Cài đặt**.
4. Mở **SLEEPMATE Pro** từ màn hình chính.

> APK này được ký bằng **debug key** để cài trực tiếp, không cần Play Store. Nếu sau này muốn phát hành chính thức, hãy tạo **release keystore** và ký lại (xem phần “Tự build APK”).

## Bước 3 — Cấp quyền để thông báo chạy khi app đóng

Lần đầu mở app, Android sẽ hỏi **Cho phép gửi thông báo** → chọn **Cho phép**.

Sau đó vào **Cài đặt → Ứng dụng → SLEEPMATE Pro**:

1. **Thông báo** → bật **Cho phép thông báo**.
2. Bật **Hiển thị trên màn hình khóa**, **Âm thanh**, **Rung**.
3. **Báo thức và nhắc nhở** (Android 12+) → bật **Báo thức chính xác** nếu có.
4. **Pin / Tiết kiệm pin** → chọn **Không tối ưu hóa** (hoặc **Không giới hạn**) để hệ thống không trì hoãn báo thức.

Trong app, tab **Câu Đố & Thông Báo**:
- Bấm **Bật thông báo** → **Test** để chắc chắn thông báo hiện.
- Bật **Báo động khi thoát màn hình**.
- Đặt **giới nghiêm** trong tab **Quản Lý Máy**.

## Cách APK nhắc nhở

- Khi bạn rời app, APK đặt **8 báo thức** tại các mốc tăng dần: 30s, 60s, 90s, 120s, 5p, 10p, 15p, 30p (theo tần suất bạn chọn 15/30/60 giây).
- Mỗi báo thức đăng một **thông báo hệ thống** kèm rung và âm thanh.
- Khi bạn mở lại app, chuỗi báo thức được **hủy ngay**.
- **Giới nghiêm** được đặt **lặp lại mỗi ngày**, kể cả khi app đã đóng.
- Sau khi **khởi động lại máy**, APK tự đặt lại báo thức giới nghiêm và chuỗi nhắc (nếu đang bật).
- Bấm vào thông báo sẽ mở app và hiện **câu đố** để tắt nhắc.

---

## Giới hạn cần biết (quan trọng)

- Cả PWA và APK **không thể đọc** thời gian bạn dùng Facebook, TikTok… (cần quyền hệ điều hành đặc biệt như Usage Access; iOS không cho phép). App đo thời gian bạn ở trong SLEEPMATE + thời gian bạn rời đi.
- **APK Android** nhắc được khi app đóng, nhưng một số máy (Xiaomi, OPPO, vivo, Samsung tối ưu pin mạnh) có thể trì hoãn báo thức nếu bạn không tắt tối ưu pin. Hãy làm bước 3.4 ở trên.
- **iPhone** không cài được APK. Muốn nhận thông báo khi app đóng hẳn cần **Web Push + máy chủ** (iOS 16.4+, đã cài ra MH chính).
- Thông báo hệ thống có thể bị **Chế độ Không làm phiền** chặn. Hãy thêm SLEEPMATE vào danh sách ngoại lệ nếu cần.

---

## Tự build lại APK

Yêu cầu: JDK 17 + Android SDK (platform 34, build-tools 34) + Gradle 8.7.

```bash
# 1. Đồng bộ HTML mới nhất vào assets
copy ..\sleepmate-pro.html sleepmate-android\app\src\main\assets\www\index.html

# 2. Trong file assets, đổi 2 dòng CDN thành file local:
#    https://cdn.tailwindcss.com  ->  ./vendor/tailwind.js
#    https://cdnjs.cloudflare.com/.../all.min.css -> ./vendor/fontawesome/css/all.min.css

# 3. Build
cd sleepmate-android
gradle assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Bản release (ký bằng keystore của bạn):

```bash
keytool -genkeypair -v -keystore sleepmate.jks -alias sleepmate -keyalg RSA -keysize 2048 -validity 10000
gradle assembleRelease
```

Thêm cấu hình `signingConfigs` trong `app/build.gradle` nếu muốn ký tự động.

---

## Cập nhật PWA sau này

1. Sửa `../sleepmate-pro.html`.
2. Copy đè vào `sleepmate-pwa/index.html`.
3. Mở `sw.js`, tăng `CORE_CACHE` và `RUNTIME_CACHE` (ví dụ `sleepmate-core-v4`).
4. Kéo thả lại thư mục lên Netlify.
5. Trên điện thoại: đóng hẳn app rồi mở lại 2 lần để service worker cập nhật.

---

## Chạy thử trên máy tính

Cần một server HTTP (không mở `file://`):

```bash
npx serve sleepmate-pwa
# hoặc
npx http-server sleepmate-pwa -p 8080
```

Mở `http://localhost:8080`. `localhost` cũng được tính là “secure context” nên service worker và thông báo hoạt động.

---

## Xử lý sự cố

| Hiện tượng | Cách xử lý |
|---|---|
| Không thấy nút “Cài app” | Phải mở bằng HTTPS + Chrome/Safari; iOS không có nút này → dùng Chia sẻ → Thêm vào MH chính |
| iPhone bấm “Bật thông báo” lại mở hướng dẫn | Chưa cài app hoặc iOS < 16.4. Thêm vào MH chính rồi mở từ icon |
| Bấm “Bật thông báo” không hiện bảng hỏi | Trước đó bạn đã chọn “Chặn”. Vào biểu tượng ổ khóa cạnh địa chỉ → Quyền → Thông báo → Cho phép |
| Thông báo không kêu | Kiểm tra chế độ Không làm phiền, âm lượng thông báo của app, và quyền “Hiển thị trên màn hình khóa” |
| APK không nhắc khi đóng app | Bật “Báo thức chính xác”, tắt tối ưu pin cho SLEEPMATE, kiểm tra quyền Thông báo |
| APK cài bị chặn | Bật “Cài từ nguồn không rõ” cho ứng dụng đang mở file APK |
| App bị lỗi sau khi cập nhật | Xóa dữ liệu trang web trong Chrome (Settings → Site settings → SLEEPMATE → Clear data) rồi mở lại |
| Icon bị cắt xấu | Android dùng `icon-maskable-512.png` (đã có safe zone), không cần sửa |
| Nút “Sao chép link” không chép được | Trình duyệt chặn clipboard. Giữ địa chỉ trên thanh trình duyệt để copy thủ công |
