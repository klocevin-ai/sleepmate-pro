package com.sleepmate.pro;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;

public final class NotificationScheduler {

    public static final String PREFS = "sleepmate_prefs";
    public static final String KEY_GUARD_CONFIG = "guard_config";
    public static final String KEY_GUARD_ENABLED = "guard_enabled";
    public static final String KEY_REPEAT_SEC = "repeat_sec";
    public static final String KEY_CURFEW_ENABLED = "curfew_enabled";
    public static final String KEY_CURFEW_HOUR = "curfew_hour";
    public static final String KEY_CURFEW_MIN = "curfew_min";

    private static final int GUARD_BASE = 2000;
    private static final int GUARD_COUNT = 8;
    private static final int CURFEW_ID = 3000;

    private NotificationScheduler() {
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }
        return true;
    }

    static void setAlarm(Context c, long triggerAt, PendingIntent pi, boolean exact) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            if (exact && canExact(c)) {
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                }
            } else {
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                } else {
                    am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                }
            }
        } catch (SecurityException e) {
            try {
                am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } catch (Exception ignored) {
            }
        }
    }

    static PendingIntent guardPending(Context c, int index) {
        Intent i = new Intent(c, GuardReceiver.class);
        i.setAction(GuardReceiver.ACTION_GUARD);
        i.putExtra("index", index);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, GUARD_BASE + index, i, flags);
    }

    static PendingIntent curfewPending(Context c) {
        Intent i = new Intent(c, GuardReceiver.class);
        i.setAction(GuardReceiver.ACTION_CURFEW);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, CURFEW_ID, i, flags);
    }

    public static void setGuardConfig(Context c, boolean enabled, int repeatSec) {
        prefs(c).edit()
                .putBoolean(KEY_GUARD_CONFIG, enabled)
                .putInt(KEY_REPEAT_SEC, clampRepeat(repeatSec))
                .apply();
        if (!enabled) cancelGuard(c);
    }

    public static boolean isGuardConfigured(Context c) {
        return prefs(c).getBoolean(KEY_GUARD_CONFIG, false);
    }

    public static int getRepeatSec(Context c) {
        return clampRepeat(prefs(c).getInt(KEY_REPEAT_SEC, 30));
    }

    private static int clampRepeat(int sec) {
        return Math.max(10, Math.min(300, sec));
    }

    public static void scheduleGuard(Context c, int repeatSec) {
        int sec = clampRepeat(repeatSec);
        prefs(c).edit()
                .putBoolean(KEY_GUARD_ENABLED, true)
                .putInt(KEY_REPEAT_SEC, sec)
                .apply();

        long now = System.currentTimeMillis();
        long[] delays = new long[]{
                sec,
                sec * 2L,
                sec * 3L,
                sec * 4L,
                Math.max(sec * 5L, 300L),
                Math.max(sec * 10L, 600L),
                Math.max(sec * 15L, 900L),
                Math.max(sec * 20L, 1800L)
        };

        for (int i = 0; i < GUARD_COUNT; i++) {
            setAlarm(c, now + delays[i] * 1000L, guardPending(c, i), true);
        }
    }

    public static void cancelGuard(Context c) {
        prefs(c).edit().putBoolean(KEY_GUARD_ENABLED, false).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < GUARD_COUNT; i++) {
            PendingIntent pi = guardPending(c, i);
            if (am != null) am.cancel(pi);
            pi.cancel();
        }
    }

    public static void scheduleDaily(Context c, int hour, int minute) {
        int h = Math.max(0, Math.min(23, hour));
        int m = Math.max(0, Math.min(59, minute));
        prefs(c).edit()
                .putBoolean(KEY_CURFEW_ENABLED, true)
                .putInt(KEY_CURFEW_HOUR, h)
                .putInt(KEY_CURFEW_MIN, m)
                .apply();
        scheduleNextCurfew(c, h, m);
    }

    static void scheduleNextCurfew(Context c, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        setAlarm(c, cal.getTimeInMillis(), curfewPending(c), true);
    }

    public static void cancelDaily(Context c) {
        prefs(c).edit().putBoolean(KEY_CURFEW_ENABLED, false).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = curfewPending(c);
        if (am != null) am.cancel(pi);
        pi.cancel();
    }

    public static void rescheduleAll(Context c) {
        SharedPreferences p = prefs(c);
        if (p.getBoolean(KEY_CURFEW_ENABLED, false)) {
            scheduleNextCurfew(c,
                    p.getInt(KEY_CURFEW_HOUR, 23),
                    p.getInt(KEY_CURFEW_MIN, 0));
        }
        if (p.getBoolean(KEY_GUARD_ENABLED, false)) {
            scheduleGuard(c, p.getInt(KEY_REPEAT_SEC, 30));
        }
    }
}
