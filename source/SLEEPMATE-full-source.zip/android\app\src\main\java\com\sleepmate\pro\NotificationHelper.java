package com.sleepmate.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

public final class NotificationHelper {

    public static final String CHANNEL_GUARD = "sleepmate_guard";
    public static final String CHANNEL_CURFEW = "sleepmate_curfew";
    public static final String CHANNEL_INFO = "sleepmate_info";

    public static final int ID_GUARD = 1001;
    public static final int ID_CURFEW = 1002;

    private static final long[] VIBRATION = new long[]{0, 450, 220, 450, 220, 600};

    private NotificationHelper() {
    }

    public static void createChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        NotificationChannel guard = new NotificationChannel(
                CHANNEL_GUARD, ctx.getString(R.string.channel_guard), NotificationManager.IMPORTANCE_HIGH);
        guard.setDescription(ctx.getString(R.string.channel_guard_desc));
        guard.enableVibration(true);
        guard.setVibrationPattern(VIBRATION);
        guard.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        guard.enableLights(true);
        guard.setLightColor(0xFFFF2A85);
        guard.setShowBadge(true);
        nm.createNotificationChannel(guard);

        NotificationChannel curfew = new NotificationChannel(
                CHANNEL_CURFEW, ctx.getString(R.string.channel_curfew), NotificationManager.IMPORTANCE_HIGH);
        curfew.setDescription(ctx.getString(R.string.channel_curfew_desc));
        curfew.enableVibration(true);
        curfew.setVibrationPattern(VIBRATION);
        curfew.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        curfew.setShowBadge(true);
        nm.createNotificationChannel(curfew);

        NotificationChannel info = new NotificationChannel(
                CHANNEL_INFO, ctx.getString(R.string.channel_info), NotificationManager.IMPORTANCE_DEFAULT);
        info.setDescription(ctx.getString(R.string.channel_info_desc));
        info.setShowBadge(false);
        nm.createNotificationChannel(info);
    }

    public static boolean areNotificationsEnabled(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return false;
        if (Build.VERSION.SDK_INT >= 24) {
            return nm.areNotificationsEnabled();
        }
        return true;
    }

    public static void show(Context ctx, String title, String body, int id, boolean ongoing) {
        if (!areNotificationsEnabled(ctx)) return;

        Intent intent = new Intent(ctx, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("from_notification", true);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(ctx, id, intent, piFlags);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(ctx, id == ID_CURFEW ? CHANNEL_CURFEW : CHANNEL_GUARD);
        } else {
            b = new Notification.Builder(ctx)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL);
        }

        b.setSmallIcon(R.drawable.ic_stat_sleep)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setCategory(id == ID_CURFEW ? Notification.CATEGORY_REMINDER : Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setColor(0xFFFF2A85);

        if (Build.VERSION.SDK_INT < 26) {
            b.setVibrate(VIBRATION);
        }
        if (ongoing) {
            b.setOngoing(true);
        }

        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        try {
            nm.notify(id, b.build());
        } catch (SecurityException ignored) {
        }
    }

    public static void vibrate(Context ctx, int ms) {
        Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        int duration = Math.max(50, Math.min(3000, ms));
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(duration);
            }
        } catch (Exception ignored) {
        }
    }
}
