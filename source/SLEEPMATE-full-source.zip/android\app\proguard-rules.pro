# Không cần rule đặc biệt — app dùng WebView + Java thuần.
